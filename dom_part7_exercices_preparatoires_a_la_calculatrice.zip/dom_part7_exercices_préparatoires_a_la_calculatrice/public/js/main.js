import './exos/exo1.js'
import './exos/exo2.js'
import './exos/exo3.js'
import './exos/exo4.js'