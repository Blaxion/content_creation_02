> https://developer.mozilla.org/fr/docs/Web/API/Node/removeChild
> Avec la methode removeChild()
## 1. 
- Utilise le second bouton pour supprimer le premier enfant
## 2. 
- Utilise le second bouton pour supprimer le dernier enfant 
## 3 .
- Utilise le dernier bouton pour supprimer un enfant au hasard


> https://developer.mozilla.org/fr/docs/Web/API/Node/replaceChild
> Avec la methode replaceChild()


## 4 . Dans la partie Remplacement de ton HTML
- Créer un élément li dans ton fichier JS
- Remplace le deuxième li par celui ci quand on clique sur le button exercice 4

## 5. 
- Créer un programme qui permet avec l'input de créer un li et de remplacer le "li" 3 par celui ci en appuyant sur le bouton exercice 5